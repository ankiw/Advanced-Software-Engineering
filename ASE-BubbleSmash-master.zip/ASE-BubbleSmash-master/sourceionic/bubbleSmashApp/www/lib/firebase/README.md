# firebase-bower

To use Firebase via Bower, do:

```bash
$ bower install firebase --save
```

NOTE: This repo is automatically generated and is not monitored for issues /
pull requests. Please contact [Firebase support](https://firebase.google.com/support/)
for any bugs / feature suggestions on Firebase or the Bower module.

LICENSE - Refer to: https://developers.google.com/terms
